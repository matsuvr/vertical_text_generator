import base64
import io
import json
import logging
import os
from datetime import datetime
from typing import Dict, List, Optional

import requests
from PIL import Image

# ログ設定
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ChromeVerticalTextTester:
    """Chrome Headless (Playwright) の縦書きレンダリングテスター"""

    def __init__(
        self,
        api_url: str = "http://localhost:8000",
        api_token: Optional[str] = None,
    ):
        self.api_url = api_url
        self.api_token = api_token or os.getenv(
            "API_TOKEN",
            "d85e469dfe0551ae45cc90413ddf9b5923eb5761ec24cf49b799bd08f3d8e264",
        )
        self.headers = {"Authorization": f"Bearer {self.api_token}"}
        self.results_dir = "test_results"
        os.makedirs(self.results_dir, exist_ok=True)
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    def run_comprehensive_test(self):
        """包括的なレンダリングテスト"""
        print("=" * 60)
        print("日本語縦書きレンダリングテスト")
        print("Chrome Headless (Playwright)")
        print("=" * 60)

        # テストケース定義
        test_cases = [
            {
                "name": "基本的な日本語",
                "text": "こんにちは、世界！\n今日はいい天気ですね。",
                "description": "基本的なひらがな、カタカナ、漢字、句読点",
            },
            {
                "name": "拗音・促音テスト",
                "text": "きゃっ！\nびっくりしちゃった。\nちょっと待って〜",
                "description": "小書き仮名の配置確認",
            },
            {
                "name": "三点リーダーテスト",
                "text": "そして…\nそれから……\nえーっと………",
                "description": "三点リーダー（…）の縦書き表示確認",
            },
            {
                "name": "3桁以上の数字テスト",
                "text": "西暦2025年\n電話番号は\n090-1234-5678\n郵便番号\n123-4567",
                "description": "3桁以上の数字は縦中横にしない",
            },
            {
                "name": "縦中横テスト",
                "text": "平成31年4月\n令和元年5月\n12月25日",
                "description": "2桁数字の縦中横処理",
            },
            {
                "name": "長文テスト",
                "text": "吾輩は猫である。名前はまだ無い。どこで生れたかとんと見当がつかぬ。何でも薄暗いじめじめした所でニャーニャー泣いていた事だけは記憶している。吾輩はここで始めて人間というものを見た。しかもあとで聞くとそれは書生という人間中で一番獰悪な種族であったそうだ。",
                "description": "長文の自動改行と複数列配置",
            },
            {
                "name": "混在テキスト",
                "text": "Webサイトの\nURL: example.com\n電話: 03-1234-5678\nメール: test@example.jp",
                "description": "英数字・記号が多いテキスト",
            },
            {
                "name": "絵文字・特殊文字",
                "text": "今日は晴れ☀️\n気温は25℃\n湿度60％です",
                "description": "絵文字と特殊文字の表示",
            },
        ]

        # 各テストケースを実行
        all_results = []

        for i, test_case in enumerate(test_cases, 1):
            print(f"\nテストケース {i}: {test_case['name']}")
            print(f"説明: {test_case['description']}")
            print("-" * 40)

            result = self.render_test(test_case, i)
            all_results.append(result)

            # 結果の表示
            self.display_test_result(result)

        # 追加テスト：異なるパラメータでのレンダリング
        print("\n" + "=" * 60)
        print("パラメータ変更テスト")
        print("=" * 60)

        param_tests = [
            {
                "name": "大きいフォント",
                "params": {"font_size": 30},
                "text": "大きな文字で\n表示します",
            },
            {
                "name": "小さいフォント",
                "params": {"font_size": 12},
                "text": "小さな文字でも\n読みやすく表示",
            },
            {
                "name": "文字間隔広め",
                "params": {"letter_spacing": 0.2},
                "text": "文字間隔を\n広げて表示",
            },
            {
                "name": "行間狭め",
                "params": {"line_height": 1.2},
                "text": "行間を狭くして\nコンパクトに表示",
            },
            {
                "name": "BudouX改行テスト（10文字）",
                "text": "これは日本語の文章を適切な位置で改行するテストです",
                "params": {"max_chars_per_line": 10},
                "description": "BudouXで10文字ごとに自然な位置で改行",
            },
            {
                "name": "BudouX改行テスト（15文字）",
                "text": "日本語の文章における自然な改行位置を判定して、読みやすい縦書きを実現します。",
                "params": {"max_chars_per_line": 15},
                "description": "BudouXで15文字ごとに自然な位置で改行",
            },
        ]

        for param_test in param_tests:
            print(f"\n{param_test['name']}")
            request_data = {
                "text": param_test["text"],
                "font_size": 20,
                "line_height": 1.6,
                "letter_spacing": 0.05,
                "padding": 20,
                "use_tategaki_js": False,
            }
            # パラメータを上書き
            request_data.update(param_test.get("params", {}))

            try:
                response = requests.post(
                    f"{self.api_url}/render",
                    json=request_data,
                    headers=self.headers,
                )
                if response.status_code == 200:
                    filename = f"param_test_{param_test['name'].replace(' ', '_')}_{self.timestamp}.png"
                    self._save_image(response.json()["image_base64"], filename)
                    print(f"✓ 保存完了: {filename}")
                else:
                    print(f"✗ エラー: {response.status_code}")
                    if response.status_code == 422:
                        print(f"  詳細: {response.json()}")
                    elif response.status_code == 500:
                        try:
                            print(f"  詳細: {response.json()}")
                        except:
                            print(f"  Response: {response.text}")
            except Exception as e:
                print(f"✗ エラー: {e!s}")

        # サマリーの表示
        self.display_summary(all_results)

        # HTMLレポートの生成
        self.generate_html_report(all_results)

    def render_test(self, test_case: Dict, test_num: int) -> Dict:
        """単一のテストケースをレンダリング"""
        request_data = {
            "text": test_case["text"],
            "font_size": 20,
            "line_height": 1.6,
            "letter_spacing": 0.05,
            "padding": 20,
            "use_tategaki_js": False,
        }

        try:
            response = requests.post(
                f"{self.api_url}/render",
                json=request_data,
                headers=self.headers,
            )

            if response.status_code == 422:
                print("\n422エラー詳細:")
                print(json.dumps(response.json(), indent=2, ensure_ascii=False))
                return {
                    "test_case": test_case,
                    "error": f"Validation Error: {response.text}",
                    "success": False,
                }

            if response.status_code != 200:
                # 500エラーの詳細を表示
                print(f"\nエラー詳細 (Status {response.status_code}):")
                try:
                    error_detail = response.json()
                    print(json.dumps(error_detail, indent=2, ensure_ascii=False))
                except:
                    print(f"Response text: {response.text}")

                return {
                    "test_case": test_case,
                    "error": f"Render Error: {response.status_code} - {response.text}",
                    "success": False,
                }

            result = response.json()

            # 画像を保存
            img = self._save_image(
                result["image_base64"],
                f"test_{test_num}_{test_case['name'].replace(' ', '_')}_{self.timestamp}.png",
            )

            # 画像の基本情報を取得
            file_size = len(base64.b64decode(result["image_base64"]))

            return {
                "test_case": test_case,
                "result": result,
                "image": img,
                "file_size": file_size,
                "success": True,
            }

        except Exception as e:
            print(f"\n例外発生: {type(e).__name__}: {e!s}")
            return {
                "test_case": test_case,
                "error": f"{type(e).__name__}: {e!s}",
                "success": False,
            }

    def _save_image(self, base64_data: str, filename: str) -> Image.Image:
        """Base64画像を保存してPIL Imageを返す"""
        image_data = base64.b64decode(base64_data)
        img = Image.open(io.BytesIO(image_data))

        # ファイルに保存
        filepath = os.path.join(self.results_dir, filename)
        img.save(filepath)

        return img

    def display_test_result(self, result: Dict):
        """テスト結果の表示"""
        if not result["success"]:
            print(f"✗ エラー: {result['error']}")
            return

        print("✓ 成功")

        # 基本情報
        res = result["result"]
        print("\n基本情報:")
        print(f"  処理時間: {res['processing_time_ms']:.2f} ms")
        print(f"  画像サイズ: {res['width']} x {res['height']} px")
        print(f"  ファイルサイズ: {result['file_size']:,} bytes")
        print(f"  トリミング: {'はい' if res['trimmed'] else 'いいえ'}")

    def display_summary(self, all_results: List[Dict]):
        """総合結果のサマリー表示"""
        print("\n" + "=" * 60)
        print("総合結果サマリー")
        print("=" * 60)

        # 成功したテストのみを集計
        successful_results = [r for r in all_results if r["success"]]

        if not successful_results:
            print("成功したテストがありません。")
            return

        # 統計情報
        total_tests = len(all_results)
        successful_tests = len(successful_results)
        failed_tests = total_tests - successful_tests

        print("\nテスト結果:")
        print(f"  総テスト数: {total_tests}")
        print(f"  成功: {successful_tests}")
        print(f"  失敗: {failed_tests}")

        if successful_results:
            # 平均処理時間
            avg_time = sum(
                r["result"]["processing_time_ms"] for r in successful_results
            ) / len(successful_results)
            print(f"\n平均処理時間: {avg_time:.2f} ms")

            # 平均ファイルサイズ
            avg_size = sum(r["file_size"] for r in successful_results) / len(
                successful_results,
            )
            print(f"平均ファイルサイズ: {avg_size:,.0f} bytes")

        print("\n技術仕様:")
        print("  - レンダリングエンジン: Chrome Headless (Playwright)")
        print("  - CSS: writing-mode: vertical-rl, text-orientation: mixed")
        print("  - OpenType: vert, vrt2, vkrn フィーチャー使用")
        print("  - フォント: 源暎アンチック / Noto Sans CJK JP")
        print("  - 自動機能: 高さ自動調整、余白トリミング")

    def generate_html_report(self, all_results: List[Dict]):
        """HTMLレポートを生成"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_path = os.path.join(self.results_dir, f"chrome_report_{timestamp}.html")

        html_content = f"""
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>Chrome縦書きレンダリングテストレポート</title>
    <style>
        body {{ font-family: 'Noto Sans JP', sans-serif; margin: 20px; background: #f5f5f5; }}
        .container {{ max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        h1 {{ color: #333; border-bottom: 3px solid #4285f4; padding-bottom: 10px; }}
        .test-case {{ border: 1px solid #ddd; margin: 20px 0; padding: 20px; border-radius: 8px; background: #fafafa; }}
        .test-case:hover {{ box-shadow: 0 2px 8px rgba(0,0,0,0.1); }}
        .image-container {{ text-align: center; margin: 20px 0; }}
        .image-container img {{ max-width: 100%; border: 2px solid #ddd; border-radius: 4px; background: white; padding: 10px; }}
        .metrics {{ background: #e8f0fe; padding: 15px; margin: 10px 0; border-radius: 4px; font-family: monospace; }}
        .success {{ color: #0d652d; background: #ceead6; padding: 5px 10px; border-radius: 4px; display: inline-block; }}
        .error {{ color: #c5221f; background: #fce8e6; padding: 5px 10px; border-radius: 4px; display: inline-block; }}
        .text-sample {{ background: #f5f5f5; padding: 10px; border-left: 4px solid #4285f4; margin: 10px 0; font-family: monospace; white-space: pre-wrap; }}
        table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
        th, td {{ border: 1px solid #ddd; padding: 12px; text-align: left; }}
        th {{ background: #4285f4; color: white; }}
        tr:nth-child(even) {{ background: #f9f9f9; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Chrome縦書きレンダリングテストレポート</h1>
        <p>生成日時: {datetime.now().strftime("%Y年%m月%d日 %H:%M:%S")}</p>
        <p>レンダリングエンジン: Chrome Headless (Playwright)</p>
"""

        # 統計情報
        successful_results = [r for r in all_results if r["success"]]
        total_tests = len(all_results)
        successful_tests = len(successful_results)

        html_content += f"""
        <div class="metrics">
            <h3>テスト統計</h3>
            <p>総テスト数: {total_tests} | 成功: {successful_tests} | 失敗: {total_tests - successful_tests}</p>
"""

        if successful_results:
            avg_time = sum(
                r["result"]["processing_time_ms"] for r in successful_results
            ) / len(successful_results)
            avg_size = sum(r["file_size"] for r in successful_results) / len(
                successful_results,
            )
            html_content += f"""
            <p>平均処理時間: {avg_time:.2f} ms | 平均ファイルサイズ: {avg_size:,.0f} bytes</p>
"""

        html_content += """
        </div>
"""

        # 各テストケース
        for i, result in enumerate(all_results, 1):
            test_case = result["test_case"]
            status_class = "success" if result["success"] else "error"
            status_text = "成功" if result["success"] else "失敗"

            html_content += f"""
        <div class="test-case">
            <h2>テストケース {i}: {test_case["name"]} <span class="{status_class}">{status_text}</span></h2>
            <p>{test_case["description"]}</p>
            <div class="text-sample">入力テキスト:\n{test_case["text"]}</div>
"""

            if result["success"]:
                res = result["result"]
                img_file = f"test_{i}_{test_case['name'].replace(' ', '_')}_{self.timestamp}.png"

                html_content += f"""
            <div class="image-container">
                <img src="{img_file}" alt="レンダリング結果">
            </div>
            <table>
                <tr><th>指標</th><th>値</th></tr>
                <tr><td>処理時間</td><td>{res["processing_time_ms"]:.2f} ms</td></tr>
                <tr><td>画像サイズ</td><td>{res["width"]} × {res["height"]} px</td></tr>
                <tr><td>ファイルサイズ</td><td>{result["file_size"]:,} bytes</td></tr>
                <tr><td>トリミング済み</td><td>{"はい" if res["trimmed"] else "いいえ"}</td></tr>
            </table>
"""
            else:
                html_content += f"""
            <p class="error">エラー: {result["error"]}</p>
"""

            html_content += """
        </div>
"""

        html_content += """
    </div>
</body>
</html>
"""

        with open(report_path, "w", encoding="utf-8") as f:
            f.write(html_content)

        print(f"\nHTMLレポートを生成しました: {report_path}")


def main():
    """メイン実行関数"""
    print("HTMLベース日本語縦書きレンダリングテスト")
    print("Chrome Headless (Playwright)")
    print("\nAPIサーバーが起動していることを確認してください。")
    print("デフォルトURL: http://localhost:8000")

    # エラー時のデバッグ方法を表示
    print("\n" + "=" * 60)
    print("エラーが発生した場合のデバッグ方法:")
    print("1. APIサーバーのログを確認: docker-compose logs -f")
    print("2. コンテナの状態を確認: docker-compose ps")
    print("3. コンテナを再起動: docker-compose restart")
    print("=" * 60 + "\n")

    # APIの起動確認
    try:
        response = requests.get("http://localhost:8000/health")
        if response.status_code != 200:
            print("\n✗ APIサーバーに接続できません。")
            return

        health_data = response.json()
        print("\n✓ APIサーバーに接続しました。")
        print(f"  バージョン: {health_data.get('version', 'unknown')}")
        print(f"  ステータス: {health_data.get('status', 'unknown')}")
    except Exception as e:
        print(f"\n✗ APIサーバーに接続できません: {e}")
        print("docker-compose up -d を実行してください。")
        return

    # APIの基本情報を表示
    try:
        response = requests.get("http://localhost:8000/")
        if response.status_code == 200:
            api_info = response.json()
            print("\nAPI情報:")
            print(f"  タイトル: {api_info.get('title', 'unknown')}")
            print(f"  説明: {api_info.get('description', 'unknown')}")

            # 機能の表示
            features = api_info.get("features", {})
            if features:
                print("\n利用可能な機能:")
                for key, value in features.items():
                    print(f"  - {key}: {value}")
    except:
        pass

    # デバッグ用HTMLの確認（オプション）
    print("\nデバッグ用HTMLを確認しますか？ (y/n): ", end="")
    if input().lower() == "y":
        try:
            # 認証ヘッダーを追加
            headers = {
                "Authorization": f"Bearer {os.getenv('API_TOKEN', 'your-secret-token-here')}",
            }
            response = requests.get(
                "http://localhost:8000/debug/html?text=テスト&font_size=20",
                headers=headers,
            )
            if response.status_code == 200:
                debug_html_path = "test_results/debug.html"
                os.makedirs("test_results", exist_ok=True)
                with open(debug_html_path, "w", encoding="utf-8") as f:
                    f.write(response.text)
                print(f"デバッグ用HTMLを保存しました: {debug_html_path}")
            elif response.status_code == 401:
                print("認証エラー: APIトークンが無効です")
        except Exception as e:
            print(f"デバッグHTML取得エラー: {e}")

    # テスターの初期化と実行
    tester = ChromeVerticalTextTester()
    tester.run_comprehensive_test()


if __name__ == "__main__":
    main()
